/* 
*JavaScript Document
*Name: Aaron Posey
*NetId: acposey
*For: Csc337 web programming class
*Instructor: Benjamin Dickens
*Final Project Enchanted Hills Baptist Church Website
*
*This JS file creates a nodeJS server using the express module.  It stands as a static server and it creates  guis to add church members, events and sermons to the DB.  The server takes POST requests and adds them to a database that stores member info, event info or sermons info.  It also queries the data bases when the proper url path is used to: 
*
*get lists of member's contact info with "/search/members
*
*get members dontion with "get/donations
*
*allow member to make donation with "donate/:amount"
*
*add member with "/add/member"
*
*get past sermons with /search/sermons, all sermons with a particular substring in thier title or description will be returned.
*
* get upcomming events with /search/events
*
*add event with "add/event"
*/


//Globals
const express = require('express')
const mongoose = require('mongoose');
const multer = require('multer');
const cookieParser = require('cookie-parser');
const {writeFileSync} = require('fs');
const ics = require('ics');
const crypto = require('crypto');

//switch hostnames and ports by comment and uncomment to go live online or stay local
//const hostname = '159.89.87.73';
const hostname = 'localhost';
//const port = 80;
const port = 3000;

const parser = require('body-parser')
const app = express()

//app settings
app.use(cookieParser());
app.use(parser.json());
app.use(parser.urlencoded({extended: true}));
app.set('json spaces', 2);

const db = mongoose.connection;
const mongoDBURL = 'mongodb://127.0.0.1/ehbc';

const cookieAge = 120000;  //change cookie age accordingly, 1000 miliseconds is 1 second  120,000 is 2 minutes
var sessionKeys = {};
var proPicHolder = '';

// Set storage variables for Multer module
var storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'public_html/uploads/images')
  },
  filename: function (req, file, cb) {
    cb(null, file.fieldname + '-' + Date.now()+ '.jpg')
  }
})
 
var upload = multer({ storage: storage })
//end set storage

var type = upload.single('photo');



//This function updates expired sessions by deleteing old cookies from the sessionKeys Object so they won't authenticate
function updateSessions() {
	console.log("updating Sessions");
	let now = Date.now();
	for (e in sessionKeys){
		if (sessionKeys[e][1] < (now - cookieAge)){
			delete sessionKeys[e];
		}
	}
}


setInterval(updateSessions, 5000);



//Schema
var Schema = mongoose.Schema;

var Members = new Schema({
	username: String,
	salt: String,
	hash: String,								
	fname: String,
	lname: String,
	email: String,
	pnum: String,
	address: String,
	donations: [{Date:String, amnt:Number}],
	proPicPath: String
})

var Sermons = new  Schema({
	title: String,
	description: String,
	created: String,
	url: String
})

var Events = new  Schema({
	title: String,
	description: String,
	when: String,
	icsstring: String
})

var aMember = mongoose.model('aMember', Members); 
var aSermon = mongoose.model('aSermon', Sermons);
var aEvent  = mongoose.model('aEvent', Events);






//***********************************************authentication code*****************************
//This function will grab the user name and login and authenticate it.  If it passes the user is assigned a sessionId and a cookie is stored.  
//Then user is rerouted to homepage.
function authenticate(req, res){
	
	
	if(Object.keys(req.cookies).length > 0 ){
		let u = req.cookies.login.user;
		let key = req.cookies.login.key;
			
			if (Object.keys(sessionKeys[u]).length > 0 && sessionKeys [u][0] == key){ // check if sessionkeys has keys and if so check if this user exist in this object
			
				//authentication good
				return true;
			}
			else {
				//authenication failed
				return false;
			}	
	}
	else{
				//no cookies to work with authentication failed
				return false;
			}
}

//setup static server
app.use(express.static('public_html'));


//setup default mongoose connection
mongoose.connect(mongoDBURL, {useNewUrlParser: true});
db.on('eeror', console.error.bind(console, 'MongoDB connection error;'));






//**************SEARCH SERMONS*************
//code for POST request from client to return a list of sermons with a particular substring in their title or description

app.post('/search/sermons/', (req, res) =>{
	
	var postParams = JSON.parse(req.body.search);
	var r = mongoose.model('aSermon', Sermons);
	
	//create query variable to search DB with keyword in both item or description
	var query = {$or:[{title: {$regex: postParams.phrase, $options: "$i"}}, {description: {$regex: postParams.phrase, $options: "$i"}}] };
	
	
	r.find(query).exec( function (error, results){
		
		
		res.setHeader('Content-Type', 'application/json');
		res.json(results);
		
	});
});




//**************ADD SERMONS*************
//code for GET request from client to return a list of items with a particular substring in their title

app.post('/add/sermons/', (req, res) =>{
	
	if(authenticate(req,res)){
	
	var postParams = JSON.parse(req.body.entry);
	
		
	
	var newSermon = new aSermon({title: postParams.title, description: postParams.desc, created: postParams.dateCreated, url:postParams.vidLoc});
	
	
	newSermon.save( function (err) {if(err) console.log('an error occurred');});
	
	res.send('Sermon added successfully');
	}
	else {
		res.send('NOT ALLOWED');
	}
		
});


//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% MEMBER SECTION %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


//**************ADD MEMBER*************
//code for POST request from client to add a user to the DB

app.post('/add/member', (req, res) => {
	var proPicHolderParsed = proPicHolder.split('/');
	var postParems = JSON.parse(req.body.newMember);
	var r = mongoose.model('aMember', Members);
	
	//clear variable for next time
	proPicHolder = '';
	
	
	r.find({username: postParems.name}).exec(function(error, results){
		if(results.length > 0){
			res.send('User already exists');
		}
	else {
		
		//generate salt and hash then store and save in DB
		var salt = crypto.randomBytes(64).toString('base64');
		var iterations = 1000;
		
		crypto.pbkdf2(postParems.pass, salt, iterations, 64, 'sha512', (err, hash) => {
		if(err) throw err;
		let hasStr = hash.toString('base64');
				
			
		var newUser = new aMember({username:postParems.name, salt: salt, hash: hasStr, fname:postParems.fname, lname:postParems.lname, email:postParems.email, pnum:postParems.pnum, address:postParems.adr, donations:[], proPicPath:proPicHolderParsed[3]});
		newUser.save( function (err) {if(err) console.log('an error occurred');});
		res.send('Acount Created');
		});
		
	}
	})
	
});






//*************MEMBER LOGIN************
//code for GET request from client to log in to a session

app.post('/login/member/', (req,res)=>{
	var postParems = JSON.parse(req.body.login)
	
	var r = mongoose.model('aMember', Members);
	
	
	var query = { username: postParems.name};
	
	r.find(query).exec( function (error, results){
		
		if (results.length == 1){
			
			//generate salt and hash then store and save in DB
		var salt = results[0].salt;
		var iterations = 1000;
		
		crypto.pbkdf2(postParems.pass, salt, iterations, 64, 'sha512', (err, hash) => {
		if(err) throw err;
		let hasStr = hash.toString('base64');
			if (results[0].hash == hasStr){
					// found the user now generate a random key for this session for this user
				let sessionKey = Math.floor(Math.random() * 1000);
				sessionKeys[postParems.name] = [sessionKey, Date.now()];

				//change maxAge higher or lower to increase or decrease session time
				res.cookie("login", {user: postParems.name, key:sessionKey}, {maxAge: cookieAge});
				res.send("Login Successful");
			}
		});		
		}
		else{
			res.send("Incorrect login, please try again.");
		}
	})
	
});




//**************SEARCH MEMBERS *************
//code for GET request from client to return a list of items with a particular substring in their title

app.post('/search/members', (req, res) =>{
	
	
	if(authenticate(req,res)){
		
	var postParams = JSON.parse(req.body.memsearch);
	var r = mongoose.model('aMember', Members);
	var query = {};
	
	//first name null and last name not do last name search
	if (postParams.fname == "" && postParams.lname != ""){
		query = {lname: {$regex: postParams.lname, $options: "$i"}};
		
	}
	//first name not null last name is null do firstname search
	else if (postParams.fname != "" && postParams.lname == ""){
		query = {fname: {$regex: postParams.fname, $options: "$i"}};
		
	}
	
	else{
	//create query variable to search DB with keyword in both item or description
	 query = {$or:[{fname: {$regex: postParams.fname, $options: "$i"}}, {lname: {$regex: postParams.lname, $options: "$i"}}] };
		
		
	}
	
	r.find(query).exec( function (error, results){
	
		res.setHeader('Content-Type', 'application/json');
		res.json(results);
		
	});
		
	}
	else {
		res.send('NOT ALLOWED');
	}
});




//**************GET ALL MEMEBERS*************
//code for GET request from client to return a list of items with a particular substring in their title

app.get('/search/members/all', (req, res) =>{
	
	if(authenticate(req,res)){
	
	var r = mongoose.model('aMember', Members);

	r.find({}).exec( function (error, results){
		
		res.setHeader('Content-Type', 'application/json');
		res.json(results);
		
	});
		
	}
	else {
		res.send('NOT ALLOWED');
	}
});



//*****************UPLOAD PROFILE PIC**************************
app.post('/upload/photo', type, (req, res, next) => {
	
	
  if (req.file) {
	  
	  proPicHolder = req.file.path;
	 
  // res.json(req.file);
	  res.send('File successfully Uploaded, hit back button to finish creating account.')
  }
	else{
   throw 'error';
	}
});


//**** **********Permission to go into Members page*******************************
app.get('/enter/members', (req, res)=>{
	
	if (authenticate(req,res)){
		
		res.send('allowed');
		
	}
	else {
		
		res.send('not allowed');
	}
	
});


//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% DONATION SECTION %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

//**************MEMBERS DONATIONS*************
//code for GET request from client to return a list of  a specific users's purchases and all their info

app.get('/get/donations', (req, res) =>{
	if(authenticate(req,res)){
	
	var user = req.cookies.login.user; 
	var r = mongoose.model('aMember', Members);
	r.findOne({username: user}).exec( function (error, result){
		
		res.setHeader('Content-Type', 'application/json');
		res.json(result.donations);
				
	});
	}
	else {
		res.send('NOT ALLOWED');
	}
});




//**********Make Donation*********
//This function allows a member to make a donation to the church.  It updates the donations list in users account.

app.get('/donate/:amount', (req, res)=> {
	
	if(authenticate(req, res)){
	
	var timeStamp = new Date();
	var donationDate = timeStamp.toDateString();
	//var itemNum = "";
	var	amount = req.params.amount;
	//var r = mongoose.model('aMember', Members);
	var Person = mongoose.model('aMember', Members);
	var userName = req.cookies.login.user;
	var donation = {Date: donationDate, amnt: amount };
	
	
	//find user in DB and update his parchases list
	Person.findOne({username: userName})
	.exec(function (err, results) {
    if (err) console.log('an error occurred');
  
    	results.donations.push(donation);
		results.save(function (err) {if(err) console.log('an error occurred');})
		
	});
		res.send('ok');
}
	else{
		res.send('NOT ALLOWED');
	}
	
    });


//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% CALENDAR SECTION %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

//**************ADD EVENT*************
//code for POST request from client to add an item to the DB

app.post('/add/event', (req, res) => {
	
	if(authenticate(req,res)){
	
	//random id for ics file generated
	var id =  Math.floor(Math.random()*1000);
	
	var postParems = JSON.parse(req.body.newEvent);
	
	//create a date object from date field sent from user
	var dt = new Date(Date.parse(postParems.date));
	
	//split time from postparems by colon into hours and minutes
	var time = []; 
	time = postParems.time.split(':');
	var hour = time[0];
	var minute = time[1];
	
	
	//object with data to pass into ics module to create event
	var icsEvent = {title: postParems.title , description: postParems.desc , start: [dt.getFullYear(), (dt.getMonth()+1), (dt.getDate()+1), hour, minute], duration: {minutes:postParems.dur}};
	
	//build path to saved ics file to store in DB
	//temp variable to hold title and strip whitespace
	let temp = postParems.title;
	//strip all whitespace
	temp = temp.replace(/\s+/g, '');
	var icsPath = './churchEvents/' + temp + 'event' + id + '.ics';
	
	//create ics file on server
	ics.createEvent(icsEvent, (error, value) => {
	if(error){
		console.log(error);
	}

	//save ICS file to memory			
	writeFileSync('./churchEvents/' + temp + 'event' + id + '.ics', value);
})
	
	
	//build date string to save in DB if hour is > 12 then change to non military time
	let ampm = 'am';
	if (hour > 12){
		hour = (hour - 12).toString();
		ampm = 'pm';
	}
	let whenStr = (dt.getMonth()+1) + '-' + (dt.getDate()+1)  + '-' + dt.getFullYear() + ' at '+ hour + ':' + minute + ampm;
	
	
	// an event to store in DB
	var newEvent = new aEvent({title: postParems.title, description: postParems.desc, when: whenStr, icsstring: icsPath })
	
	//save into DB
	newEvent.save( function (err) {if(err) console.log('an error occurred');});

//});
	res.send('Event Created');
	}
	else{
		res.send('NOT ALLOWED');
	}
});



//**************SHOW EVENTS*************
//code for GET request from client to return a list of items with a particular substring in their title

app.get('/show/events', (req, res) =>{
	
	
	var r = mongoose.model('aEvent', Events);
	
	
	r.find({}).exec( function (error, results){
		
		
		res.setHeader('Content-Type', 'application/json');
		res.json(results);
		
	});
});


//***************Download ICS******************
app.get('/download/:FOLDER/:FILE', (req, res) =>{
	
	
	
 var fp = './' + req.params.FOLDER + '/'+ req.params.FILE 

 res.download(fp);

});

/************************************************************************************************************************************ 
*This section starts the server and listens for requests from user.  
*************************************************************************************************************************************/


app.listen(port, () => 
  console.log(`App listening at http://${hostname}:${port}`))
