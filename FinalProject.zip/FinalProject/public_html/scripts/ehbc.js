/* 
*JavaScript Document for EHBC website the controller part of the MVC
*Name: Aaron Posey
*NetId: acposey
*For: Csc337 web programming class
*Instructor: Benjamin Dickens
*Final Project (Make Over of Enchanted Hills Baptist Church Website)
*
*This JS file is allows the user to interact with the Enchanted Hills Baptist Church Website.  This JS  script is used as a controller to communicate between the client and server.
*There are three main sections.  The interactions with Sermons, the Church Events interactions, and the Member interactions 
*/
 


//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% SERMON PAGE FUNCTIONS %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//This function allows the user to add a Sermon to the database
function addSermon(){
	
	// get fields with info from user
	var sTitle = document.getElementById("title");
	var sDesc = document.getElementById("description");
	var sDate = document.getElementById("created");
	var sUrl = document.getElementById("url4vid");
	
	//add values from fields to an object
	var newEntry = {title: sTitle.value, desc: sDesc.value, dateCreated: sDate.value, vidLoc:sUrl.value};
	var strnewEntry = JSON.stringify(newEntry);
	
	
	//create ajax request and send POST to server 
	$.ajax({
			url: '/add/sermons/',
			data: {entry:strnewEntry},
			method: 'POST',
			success: function(results){
				
					//reroute to login page if session expired
			if(results == 'NOT ALLOWED'){
				alert("Session Expired need to login again");
				window.location.href='./login.html';
			}
				alert(results);
			}
	});
	
	
	//clear text fields
	sTitle.value = '';
	sDesc.value = '';
	sDate.value = '';
	sUrl.value = '';
}


//This function searches for a Sermon from the database
function findSermon(){
	
	let sTitle = '';
	let sUrl = '';
	let bg ='';
	
	
	//get search value and setup an object for server request
	var kw = document.getElementById('searchBar').value;
	let aSearch = {phrase : kw};
	let searchStr = JSON.stringify(aSearch);
	
	$.ajax({
			url: '/search/sermons/',
			data: {search:searchStr},
			method: 'POST',
			success: function(results){
				
				
				//grab results dive from DOM
				let resOutput = document.getElementById('sResults');
				//need to clear iinerHtml here everytime.
				resOutput.innerHTML = '';
				
				
				//create html to show results of DB query 
				for(i in results){
					
					sTitle = results[i].title;
					sUrl = results[i].url;
					bg = '/img/bkgrndsForSermons/bg' + (i % 5) + '.jpg';
					aSermonResult = '<div class=\"sermon2show\"><h1>'+sTitle+'</h1><p><div class=\"bgContainer\"><img src=\"'+bg+'\" alt=\"background\"/><button onclick=\"addVidPlayer(\''+sUrl+'\');\" class=\"bgButt\">Play</button>'; 
					
					resOutput.innerHTML += aSermonResult;
				}
			}
	
	});	
}






function addVidPlayer(url){
	
	vidId = url.split('/');
	
	//want vidId[3]
	var videoPlayerEmbed = document.getElementById("vidWrapper");
	videoPlayerEmbed.innerHTML = '<iframe width=\"550\" height=\"345\" src=\"https://www.youtube.com/embed/'+vidId[3]+'?autoplay=1\"></iframe>';
	window.scroll(0,0);
}




//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% member page functions %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

//This function adds a new member to the database
function addMember(){
	
	var username = document.getElementById('newUserName').value;
	var pw = document.getElementById('newPassword').value;
	var firstname = document.getElementById('firstName').value;
	var lastname = document.getElementById('lastName').value;
	var newemail = document.getElementById('mbremail').value;
	var phone = document.getElementById('phone').value;
	var address = document.getElementById('address').value;
	
	let member = {name: username, pass: pw, fname:firstname, lname:lastname, email:newemail, pnum:phone, adr:address};
	let userStr = JSON.stringify(member);
	
	
	$.ajax({
		url: '/add/member',
		data: {newMember: userStr},
		method: 'POST',
		success: function(result){
			
			alert(result);
		}
	})
}

//This function logs the user in to the member only restricted sections
function memberLogin(){
	
	var username = document.getElementById("userName").value;
	var pw = document.getElementById("password").value;
	
	let member = {name: username, pass: pw};
	let usrStr = JSON.stringify(member);
	
	$.ajax({
		url: '/login/member',
		data: {login: usrStr},
		method: 'POST',
		success: function(result){
			
			alert(result);
			
			if (result == 'Login Successful'){
				window.location.href='./members.html';
			}
		}
	})
}

//This function allows the user to search for other members contact info from the church member directory
function searchMembers(){
	
	var firstname = document.getElementById("firstname").value;
	var lastname = document.getElementById("lastname").value;
	
	let search = {fname: firstname, lname: lastname };
	let searchStr = JSON.stringify(search);
	
	var aMemberResult = '';
	var imgPath = 'img/crosee4corner.png';
	
	$.ajax({
		url: '/search/members',
		data: {memsearch: searchStr},
		method: 'POST',
		success: function(result){
			
					//reroute to login page if session expired
			if(result == 'NOT ALLOWED'){
				alert("Session Expired need to login again");
				window.location.href='./login.html';
			}
			
			let fname = '';
			let lname = '';
			let email = '';
			let phone = '';
			let adr = '';
			let resOutput = document.getElementById("foundMemberResults")
			
			//need to clear iinerHtml here everytime.
				resOutput.innerHTML = '';
				
				
				//create html to show results of DB query 
				for(i in result){
					
					fname = result[i].fname;
					lname = result[i].lname;
					email = result[i].email;
					phone = result[i].pnum;
					adr = result[i].address;
					if( typeof result[i].proPicPath !== 'undefined'){
						
					imgPath = '/uploads/images/' + result[i].proPicPath;
					}
					
				
					
					aMemberResult = '<div id = \"memberesult\"><img id = \"profilePic\" src= \"'+ imgPath+'\" alt = \"profile pic\"/><div id = \"resultInfo\"><p>First Name: ' + fname + '</p><p>Last Name: ' +lname+ '</p><p>Email: ' + email + '</p><p>Phone: ' +phone+'</p><p>Address: ' +adr + '</p></div></div>'; 
					
					resOutput.innerHTML += aMemberResult;
				}
		}
	})
	
}

//This function returns the whole church member directory for the user
function getDirectory(){
	
	var imgPath = 'img/crosee4corner.png';
	
	$.ajax({
		url: '/search/members/all',
		method: 'GET',
		success: function(result){
			
					//reroute to login page if session expired
			if(result == 'NOT ALLOWED'){
				alert("Session Expired need to login again");
				window.location.href='./login.html';
			}
			
			let fname = '';
			let lname = '';
			let email = '';
			let phone = '';
			let adr = '';
			let resOutput = document.getElementById("foundMemberResults")
			
			//need to clear iinerHtml here everytime.
				resOutput.innerHTML = '';
				
				
				//create html to show results of DB query 
				for(i in result){
					
					fname = result[i].fname;
					lname = result[i].lname;
					email = result[i].email;
					phone = result[i].pnum;
					adr = result[i].address;
					if(typeof result[i].proPicPath !== 'undefined'){
					imgPath = '/uploads/images/' + result[i].proPicPath;
					}
				
					aMemberResult = '<div id = \"memberesult\"><img id = \"profilePic\" src= \"'+ imgPath+'\" alt = \"profile pic\"/><div id = \"resultInfo\"><p>First Name: ' + fname + '</p><p>Last Name: ' +lname+ '</p><p>Email: ' + email + '</p><p>Phone: ' +phone+'</p><p>Address: ' +adr + '</p></div></div>'; 
					
					resOutput.innerHTML += aMemberResult;
				}
			
		}
	})
}


//This function allows the user to make a donation to the Church
function makeDonation(){
	
	var donation = document.getElementById("donationAmount").value;
	var customUrl = '/donate/' + donation;
	
	$.ajax({
		url: customUrl,
		method: 'GET',
		success: function(result){
			
					//reroute to login page if session expired
			if(result == 'NOT ALLOWED'){
				alert("Session Expired need to login again");
				window.location.href='./login.html';
			}
			
			alert(result);
			
		}
	})
}

//This function allows the user to get a copy of their donation history to the church 
function donateHistory(){
	   
	$.ajax({
		url: '/get/donations',
		method: 'GET',
		success: function(result){
			
					//reroute to login page if session expired
			if(result == 'NOT ALLOWED'){
				alert("Session Expired need to login again");
				window.location.href='./login.html';
			}
			
			alert(result);
			
		}
	})
}

//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% EVENT PAGE FUNCTIONS %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

//This function allows the user to add a calendar event to the church website
function addCalEvent(){
	
	//get values from fields when user clicks button
	var title = document.getElementById("eventTitle").value;
	var desc = document.getElementById("eventDesc").value;
	var date = document.getElementById("eventDate").value;
	var time = document.getElementById("eventTime").value;
	var duratiion = document.getElementById("eventDur").value;
	
	//create an event object and stringify it
	var event = {title:title, desc:desc, date:date, time:time, dur:duratiion};
	var newEventStr = JSON.stringify(event);
	
	
	$.ajax({
		url: '/add/event',
		method: 'POST',
		data: {newEvent:newEventStr},
		success: function(result){
			
					//reroute to login page if session expired
			if(result == 'NOT ALLOWED'){
				alert("Session Expired need to login again");
				window.location.href='./login.html';
			}
			
			alert(result);
			
		}
	})
	
}


//This function populates the list of current church events
function showEvents(){
	
	//var currentEvents = document.getElementById('currentEventsDiv');
	var anEventResult = '';
	
	$.ajax({
		url: '/show/events',
		method: 'GET',
		success: function(result){
			
			let title = '';
			let description ='';
			let when = '';
			let icsstring = '';
			let resOutput = document.getElementById('foundEvents');
			let date = [];
			
			
			
			//need to clear innterHTML here everytime
					resOutput.innerHTML = '';
			
			//create html to show results of DB query 
				for(i in result){
					date = result[i].when.split('-');
					
					switch (date[0]){
							
						case '1':
							date[0]= 'JAN'
							break;
						case '2':
							date[0]= 'FEB'
							break;
						case '3':
							date[0]= 'MAR'
							break;
						case '4':
							date[0]= 'APR'
							break;
						case '5':
							date[0]= 'MAY'
							break;
						case '6':
							date[0]= 'JUN'
							break;
						case '7':
							date[0]= 'JUL'
							break;
						case '8':
							date[0]= 'AUG'
							break;
						case '9':
							date[0]= 'SEP'
							break;
						case '10':
							date[0]= 'OCT'
							break;
						case '11':
							date[0]= 'NOV'
							break;
						case '12':
							date[0]= 'DEC'
							break;
					}
					
					title = result[i].title;
					description = result[i].description;
					when = result[i].when;
					icsstring = result[i].icsstring;
					
					anEventResult = '<div id=\"calendarLogo\"><div id =\"topcallogo\"><p>'+date[0]+'</p></div><div id =\"bottCallogo\"><p id =\"caldate\">'+date[1]+'</p></div></div><div id =\"eventinfo\"><p>Title: '+ title+'</p><p>When: '+when+'</p> <p>Description: '+description+'</p></div><button onclick = \"dwnldICS(\''+icsstring+'\')\";>Add event to your Device</button>';
					
					resOutput.innerHTML += anEventResult;
				}	
		}
	})
}

//This function allows the user to download the ICS file to place the event into their device's calendar
function dwnldICS(fp){
	
	var customUrl = ''
	var fpParsed = fp.split('/');
	var folder ='';
	var file = '';
	
	customUrl = '/download/' + fpParsed[1] +'/' + fpParsed[2];
	
	
	window.location = customUrl;
}


//This code is to force an authentication check when user tries to enter members page
function enterMemberPage(){
	
	$.ajax({
		url: '/enter/members',
		method: 'GET',
		success: function(result){
			if(result == 'not allowed'){
				window.location.href='./login.html';
			}
			 	
		}
	})
}
